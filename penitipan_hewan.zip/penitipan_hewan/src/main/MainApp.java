package penitipan_hewan.main;

import penitipan_hewan.service.CrudService;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CrudService crud = new CrudService(scanner);
        boolean running = true;

        while (running) {
            System.out.println("\n=== SISTEM PENITIPAN HEWAN ===");
            System.out.println("1. CRUD Hewan");
            System.out.println("2. CRUD Pemilik");
            System.out.println("3. CRUD Petugas");
            System.out.println("4. CRUD Transaksi");
            System.out.println("5. CRUD Cari");
            System.out.println("6. Keluar");
            System.out.print("Pilih menu: ");

            String menu = scanner.nextLine();
            switch (menu) {
                case "1" -> {
                    System.out.println("\n--- CRUD HEWAN ---");
                    System.out.println("1. Tambah");
                    System.out.println("2. Lihat");
                    System.out.println("3. Ubah");
                    System.out.println("4. Hapus");
                    System.out.print("Pilih: ");
                    String c = scanner.nextLine();
                    switch (c) {
                        case "1" -> crud.tambahHewan();
                        case "2" -> crud.lihatHewan();
                        case "3" -> crud.ubahHewan();
                        case "4" -> crud.hapusHewan();
                        default -> System.out.println("Pilihan tidak tersedia.");
                    }
                }
                case "2" -> {
                    System.out.println("\n--- CRUD PEMILIK ---");
                    System.out.println("1. Tambah");
                    System.out.println("2. Lihat");
                    System.out.println("3. Ubah");
                    System.out.println("4. Hapus");
                    System.out.print("Pilih: ");
                    String c = scanner.nextLine();
                    switch (c) {
                        case "1" -> crud.tambahPemilik();
                        case "2" -> crud.lihatPemilik();
                        case "3" -> crud.ubahPemilik();
                        case "4" -> crud.hapusPemilik();
                        default -> System.out.println("Pilihan tidak tersedia.");
                    }
                }
                case "3" -> {
                    System.out.println("\n--- CRUD PETUGAS ---");
                    System.out.println("1. Tambah");
                    System.out.println("2. Lihat");
                    System.out.println("3. Ubah");
                    System.out.println("4. Hapus");
                    System.out.print("Pilih: ");
                    String c = scanner.nextLine();
                    switch (c) {
                        case "1" -> crud.tambahPetugas();
                        case "2" -> crud.lihatPetugas();
                        case "3" -> crud.ubahPetugas();
                        case "4" -> crud.hapusPetugas();
                        default -> System.out.println("Pilihan tidak tersedia.");
                    }
                }
                case "4" -> {
                    System.out.println("\n--- CRUD TRANSAKSI ---");
                    System.out.println("1. Tambah");
                    System.out.println("2. Lihat");
                    System.out.println("3. Ubah");
                    System.out.println("4. Hapus");
                    System.out.print("Pilih: ");
                    String c = scanner.nextLine();
                    switch (c) {
                        case "1" -> crud.tambahTransaksi();
                        case "2" -> crud.lihatTransaksi();
                        case "3" -> crud.ubahTransaksi();
                        case "4" -> crud.hapusTransaksi();
                        default -> System.out.println("Pilihan tidak tersedia.");
                    }
                }
                case "5" -> {
                    System.out.println("\n--- CRUD CARI ---");
                    System.out.println("1. Cari Hewan  ");
                    System.out.println("2. Cari Petugas");
                    System.out.println("3. Cari Pemilik");
                    System.out.println("4. Cari Transaksi");
                    System.out.print("Pilih: ");
                    String c = scanner.nextLine();
                    switch (c) {
                        case "1" -> crud.cariHewan();
                        case "2" -> crud.cariPemilik();
                        case "3" -> crud.cariPetugas();
                        case "4" -> crud.cariTransaksi();
                        default -> System.out.println("Pilihan tidak tersedia.");
                    }
                }
                case "6" -> {
                    running = false;
                    System.out.println("👋 Terima kasih!");
                }
                default -> System.out.println("Pilihan tidak tersedia.");
            }
        }

        scanner.close();
    }
}
