abstract class BangunDatar {
    // Metode abstrak untuk menghitung luas
    public abstract double hitungLuas();

    // Metode abstrak untuk menghitung keliling
    public abstract double hitungKeliling();
}

// Kelas Persegi yang mewarisi BangunDatar
class Persegi extends BangunDatar {
    private double sisi;

    // Konstruktor untuk inisialisasi sisi persegi
    public Persegi(double sisi) {
        this.sisi = sisi;
    }

    // Implementasi metode hitungLuas
    @Override
    public double hitungLuas() {
        return sisi * sisi;
    }

    // Implementasi metode hitungKeliling
    @Override
    public double hitungKeliling() {
        return 4 * sisi;
    }

    // Getter untuk sisi
    public double getSisi() {
        return sisi;
    }

    // Setter untuk sisi
    public void setSisi(double sisi) {
        this.sisi = sisi;
    }
}

public class Main {
    public static void main(String[] args) {
        // Membuat objek bangun datar
        BangunDatar persegi = new Persegi(4); // sisi = 4

        // Menampilkan hasil perhitungan luas dan keliling
        System.out.println("Luas Persegi: " + persegi.hitungLuas() + ", Keliling: " + persegi.hitungKeliling());
        
    }
}