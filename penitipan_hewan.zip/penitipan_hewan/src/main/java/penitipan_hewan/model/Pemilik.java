package penitipan_hewan.model;

public class Pemilik extends Orang {
    private String alamat;
    private String noHp;

    public Pemilik(String nama, int umur, String alamat, String noHp) {
        super(nama, umur);
        this.alamat = alamat;
        this.noHp = noHp;
    }

    public String getAlamat() { return alamat; }
    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getNoHp() { return noHp; }
    public void setNoHp(String noHp) { this.noHp = noHp; }

    @Override
    public String toString() {
        return super.toString() + ", Alamat: " + alamat + ", No HP: " + noHp;
    }
}
